import { Injectable, InternalServerErrorException } from "@nestjs/common";
require('dotenv').config()

const {
  TWILIO_ACCOUNT_SID,
  TWILIO_AUTH_TOKEN,
  TWILIO_SERVICE_SID
} = process.env


const client = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN,{lazyLoading:true});

@Injectable()
export class TwilioService{
  constructor(){}

  async twilioSendOTP(phone_number:string,channel:string){
    const sendOTP = client.verify.v2.services(TWILIO_SERVICE_SID)
    .verifications
      .create({
        to: `+${phone_number}`,
        channel
       })
      .then((message:any)=> {
        return message
      })
      .catch((err:any)=> {
        throw new InternalServerErrorException('Twilio Server Error',{cause:new Error(err)})
      });
      return sendOTP
  }

  async verifyOTP(phone_number:string,otp:string){
    const clientResponse  = await client.verify.v2.services(TWILIO_SERVICE_SID)
    .verificationChecks
    .create({to: `+${phone_number}`, code: `${otp}`})
    return clientResponse.valid;
  }
}
