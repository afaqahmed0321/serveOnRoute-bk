import {Action} from './action.enum'
 
const Permission = {
  ...Action,
  
}
 
type Permission = Action ;
 
export default Permission;