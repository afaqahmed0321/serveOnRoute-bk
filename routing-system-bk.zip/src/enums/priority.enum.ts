export enum PRIORITY{
    PRIMARY='primary',
    SECONDARY='secondary',
    NON_PRIMARY = 'non_primary'
}