export default interface LoginResponseInterface {
  readonly access_token: string;
  readonly roles: any;
}
