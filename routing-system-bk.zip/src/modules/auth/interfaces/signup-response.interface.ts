export default interface SignupResponseInterface {
  readonly access_token: string;
  readonly roles: [];
}