export class Dashboard {}
