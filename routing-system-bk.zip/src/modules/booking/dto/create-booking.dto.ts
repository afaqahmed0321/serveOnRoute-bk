export class CreateBookingDto {}
