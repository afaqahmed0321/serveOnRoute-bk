import { ObjectId } from "mongodb";

export class CreateConversationDto{
    members:[string]
    parcel:string
}